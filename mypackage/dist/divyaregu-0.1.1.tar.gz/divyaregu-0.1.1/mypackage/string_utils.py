def to_uppercase(s):
    return s.upper()

def to_lowercase(s):
    return s.lower()

def reverse_string(s):
    return s[::-1]
